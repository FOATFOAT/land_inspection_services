var pdfMake = pdfMake || {};
pdfMake.vfs = {
    'THSarabunNew.ttf': 'data:font/truetype;base64,AAEAAAARAQAABAAQR0RFRgAAAAEAAAAVAAA...<Base64 ฟอนต์ THSarabunNew>',
    'THSarabunNew Bold.ttf': 'data:font/truetype;base64,AAEAAAARAQAABAAQR0RFRgAAAAEAAAAVAAA...<Base64 ฟอนต์ THSarabunNew Bold>',
    'THSarabunNew Italic.ttf': 'data:font/truetype;base64,AAEAAAARAQAABAAQR0RFRgAAAAEAAAAVAAA...<Base64 ฟอนต์ THSarabunNew Italic>',
    'THSarabunNew BoldItalic.ttf': 'data:font/truetype;base64,AAEAAAARAQAABAAQR0RFRgAAAAEAAAAVAAA...<Base64 ฟอนต์ THSarabunNew BoldItalic>'
};
