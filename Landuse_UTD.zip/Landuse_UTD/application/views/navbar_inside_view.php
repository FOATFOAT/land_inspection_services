<style>

ol, ul {
    padding-left: 0rem;
}

</style>

<div class="sidebar open">
      <div class="logo-details">
        <!-- <i class="bx bxl-c-plus-plus icon"></i> -->
          <img class="logo_name" src="<?php echo base_url();?>assets/img/ANDTOWNCOUNTRYPLANNING.png" alt="" style="width: 15%;"> &nbsp;&nbsp;
        <div class="logo_name">DPT</div>
        <i class="bx bx-menu" id="btn"></i>
      </div>
      <ul class="nav-list">
        <li>
          <i class="bx bx-search"></i>
          <input type="text" placeholder="Search..." />
          <span class="tooltip">Search</span>
        </li>
        <li>
          <a href="#">
            <i class="bx bx-grid-alt"></i>
            <span class="links_name">หน้าจัดการ</span>
          </a>
          <span class="tooltip">หน้าจัดการ</span>
        </li>
        <li>
          <a href="#">
            <i class="bx bx-user"></i>
            <span class="links_name">User</span>
          </a>
          <span class="tooltip">User</span>
        </li>
        <li>
          <a href="#">
            <i class="bx bx-chat"></i>
            <span class="links_name">Messages</span>
          </a>
          <span class="tooltip">Messages</span>
        </li>
        <li>
          <a href="#">
            <i class="bx bx-pie-chart-alt-2"></i>
            <span class="links_name">Analytics</span>
          </a>
          <span class="tooltip">Analytics</span>
        </li>
        <li>
          <a href="#">
            <i class="bx bx-folder"></i>
            <span class="links_name">File Manager</span>
          </a>
          <span class="tooltip">Files</span>
        </li>
        <!-- <li>
          <a href="#">
            <i class="bx bx-cart-alt"></i>
            <span class="links_name">Order</span>
          </a>
          <span class="tooltip">Order</span>
        </li> -->
        <!-- <li>
          <a href="#">
            <i class="bx bx-heart"></i>
            <span class="links_name">Saved</span>
          </a>
          <span class="tooltip">Saved</span>
        </li> -->
        <li>
          <a href="#">
            <i class="bx bx-cog"></i>
            <span class="links_name">Setting</span>
          </a>
          <span class="tooltip">Setting</span>
        </li>
        <li class="profile">
          <div class="profile-details">
          <img class="" src="<?php echo base_url();?>assets/img/นายฉัตรมงคล ฮาดฟอง.jpg" alt="profileImg" style="">
            <!-- <img src="profile.jpg" alt="profileImg" /> -->
            <div class="name_job">
              <div class="name">Prem Shahi</div>
              <div class="job">Web designer</div>
            </div>
          </div>
          <i class="bx bx-log-out" id="log_out"></i>
        </li>
      </ul>
    </div>
    <!-- <section class="home-section">
        <div class="text">Dashboard</div>
        <div class="container text-center">
        <div class="row">
            <div class="col">
            Column
            </div>
            <div class="col">
            Column
            </div>
            <div class="col">
            Column
            </div>
        </div>
        </div>
      
    </section> -->


    <script>


// // ดึงขนาดหน้าจอ
// var screenWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
// var screenHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;

// // แสดงขนาดหน้าจอใน console
// console.log("Width: " + screenWidth + " Height: " + screenHeight);

    </script>