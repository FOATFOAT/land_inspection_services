

  
      
  <!-- <script src="../assets/libs/jquery/dist/jquery.min.js"></script>
  <script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/sidebarmenu.js"></script>
  <script src="../assets/js/app.min.js"></script>
  <script src="../assets/libs/apexcharts/dist/apexcharts.min.js"></script>
  <script src="../assets/libs/simplebar/dist/simplebar.js"></script>
  <script src="../assets/js/dashboard.js"></script> -->

  <!-- <script src="<?php echo site_url('assets_inside/js/app.min.js'); ?>"></script> -->
  <script src="<?php echo site_url('assets_inside/js/sidebarmenu.js'); ?>"></script>
  <script src="<?php echo site_url('assets_inside/js/app.min.js'); ?>"></script>
  <!-- <script src="<?php echo site_url('assets_inside/libs/apexcharts/dist/apexcharts.min.js'); ?>"></script> -->
  <script src="<?php echo site_url('assets_inside/libs/simplebar/dist/simplebar.js'); ?>"></script>
  <!-- <script src="<?php echo site_url('assets_inside/js/dashboard.js'); ?>"></script> -->

   <!-- icon -->
   <script>
      feather.replace();
    </script>





   <!-- datatables -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<!-- ปุ่มต่างๆ -->
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>


    <!-- pdfmake -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

     <!-- Custom Fonts -->
     <script src="<?php echo site_url('assets_inside/Tables_function/fonts/custom_vfs_fonts.js'); ?>"></script> <!-- เพิ่มการอ้างอิงไปยังไฟล์ fonts.js -->


  <!-- กำหนดฟอนต์ -->
  <script>

    // pdfMake.fonts = {
    //     THSarabunNew: {
    //         normal: 'THSarabunNew.ttf',
    //         bold: 'THSarabunNew-Bold.ttf',
    //         italics: 'THSarabunNew-Italic.ttf',
    //         bolditalics: 'THSarabunNew-BoldItalic.ttf'
    //     }
    // };

    // pdfMake.vfs = {
    //     'THSarabunNew.ttf': 'data:font/ttf;base64,/* base64 ของ THSarabunNew.ttf */',
    //     'THSarabunNew-Bold.ttf': 'data:font/ttf;base64,/* base64 ของ THSarabunNew-Bold.ttf */',
    //     'THSarabunNew-Italic.ttf': 'data:font/ttf;base64,/* base64 ของ THSarabunNew-Italic.ttf */',
    //     'THSarabunNew-BoldItalic.ttf': 'data:font/ttf;base64,/* base64 ของ THSarabunNew-BoldItalic.ttf */'
    // };

  </script>





</body>

</html>