    <!-- Load Require CSS -->
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font CSS -->
    <link href="<?php echo base_url();?>assets/css/boxicon.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Load Tempalte CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/templatemo.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/custom.css">

    <!-- -----------------------เพิ่มเอง-------------------------- -->

     <!-- style CSS -->
     <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">

    <!-- jquery -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <!-- icon -->
    <script src="https://unpkg.com/feather-icons"></script>

    <!-- font Kanit -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">

    <!-- Select2 -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> -->


    
<!--
    
TemplateMo 561 Purple Buzz

https://templatemo.com/tm-561-purple-buzz

-->

<style>
    .font-ram{
        font-family: 'Kanit', sans-serif;
    }

    #s-ttl { /* ชื่อสำนักงานของคุกกี่้ */
    display: table-cell;
    font-size: 25px;
    }
    #cs { /* ฟอนต์คุกกี่้ด้านใน */
    font-family: 'Kanit', sans-serif;
    }
    #cc_div #cm { /* ฟอนต์คุกกี่้ด้านนอก */
    display: block!important;
    font-family: 'Kanit', sans-serif;
    }

</style>

</head>

<body class="font-ram theme_funky">