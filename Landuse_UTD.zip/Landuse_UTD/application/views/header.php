  <!DOCTYPE html>
<html lang="en">
<!-- <html lang="en"> -->

<head>
    <title>กรมโยธาธิการและผังเมือง</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="apple-touch-icon" href="assets/img/apple-icon.png"> -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/img/ANDTOWNCOUNTRYPLANNING.png">
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />