   <!-- icon -->
   <script>
      feather.replace();
    </script>




    <!-- <script src="script.js" defer></script> -->
    <script defer src="<?php echo site_url('assets/js/system_inside.js'); ?>"></script>


   <!-- dataTables -->
<!-- <script src="https://cdn.datatables.net/2.0.7/js/dataTables.js"></script> -->




</body>
</html>