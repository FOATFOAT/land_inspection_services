<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-08 09:57:54 --> 404 Page Not Found: Assets/img
