<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:01:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:03:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 05:04:02 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:29:25 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:23 --> 404 Page Not Found: Images/8411fefe0842102747e390a1d834cbd6.jpg
ERROR - 2024-05-02 06:32:23 --> 404 Page Not Found: Images/dbf804b437832d693e2a275ae52f7655.png
ERROR - 2024-05-02 06:32:23 --> 404 Page Not Found: Images/1b16e01bfc24684af9b7e53b5a200e3f.png
ERROR - 2024-05-02 06:32:24 --> 404 Page Not Found: Images/5129161a4cd124e49cdd1c0cdf994a7a.jpg
ERROR - 2024-05-02 06:32:31 --> 404 Page Not Found: Images/5129161a4cd124e49cdd1c0cdf994a7a.jpg
ERROR - 2024-05-02 06:32:32 --> 404 Page Not Found: Images/5129161a4cd124e49cdd1c0cdf994a7a.jpg
ERROR - 2024-05-02 06:32:32 --> 404 Page Not Found: Images/5129161a4cd124e49cdd1c0cdf994a7a.jpg
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:32:34 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 06:33:05 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = ''
ERROR - 2024-05-02 14:03:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:03:43 --> JPG images are not supported.
ERROR - 2024-05-02 14:03:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:03:43 --> PNG images are not supported.
ERROR - 2024-05-02 14:03:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:03:43 --> JPG images are not supported.
ERROR - 2024-05-02 14:03:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:03:43 --> JPG images are not supported.
ERROR - 2024-05-02 14:03:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:03:43 --> JPG images are not supported.
ERROR - 2024-05-02 14:03:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:03:43 --> JPG images are not supported.
ERROR - 2024-05-02 14:03:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:03:43 --> JPG images are not supported.
ERROR - 2024-05-02 14:03:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:03:43 --> PNG images are not supported.
ERROR - 2024-05-02 14:03:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:03:43 --> JPG images are not supported.
ERROR - 2024-05-02 14:03:43 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:03:43 --> JPG images are not supported.
ERROR - 2024-05-02 14:09:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:09:59 --> JPG images are not supported.
ERROR - 2024-05-02 14:09:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:09:59 --> PNG images are not supported.
ERROR - 2024-05-02 14:09:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:09:59 --> JPG images are not supported.
ERROR - 2024-05-02 14:09:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:09:59 --> JPG images are not supported.
ERROR - 2024-05-02 14:09:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:09:59 --> JPG images are not supported.
ERROR - 2024-05-02 14:09:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:09:59 --> JPG images are not supported.
ERROR - 2024-05-02 14:09:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:09:59 --> JPG images are not supported.
ERROR - 2024-05-02 14:09:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:09:59 --> PNG images are not supported.
ERROR - 2024-05-02 14:09:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:09:59 --> JPG images are not supported.
ERROR - 2024-05-02 14:09:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-05-02 14:09:59 --> JPG images are not supported.
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:08 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:41 --> 404 Page Not Found: Images/9474075_20240502.png
ERROR - 2024-05-02 12:08:41 --> 404 Page Not Found: Images/1311299_20240502.jpg
ERROR - 2024-05-02 12:08:41 --> 404 Page Not Found: Images/3485132_20240502.jpg
ERROR - 2024-05-02 12:08:45 --> 404 Page Not Found: Images/9184902_20240502.png
ERROR - 2024-05-02 12:08:45 --> 404 Page Not Found: Images/7184542_20240502.jpg
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:08:59 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-02 12:09:01 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = 'PER0000041'
ERROR - 2024-05-02 12:09:04 --> 404 Page Not Found: Images/5129161a4cd124e49cdd1c0cdf994a7a.jpg
ERROR - 2024-05-02 12:09:07 --> 404 Page Not Found: Images/1311299_20240502.jpg
ERROR - 2024-05-02 12:09:07 --> 404 Page Not Found: Images/3485132_20240502.jpg
ERROR - 2024-05-02 12:09:07 --> 404 Page Not Found: Images/9474075_20240502.png
