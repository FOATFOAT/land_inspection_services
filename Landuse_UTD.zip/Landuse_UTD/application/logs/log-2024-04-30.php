<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-30 09:14:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_utt-dpt' C:\xampp\htdocs\Landuse_UTD\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2024-04-30 09:14:32 --> Unable to connect to the database
ERROR - 2024-04-30 09:19:04 --> 404 Page Not Found: Receive/index
