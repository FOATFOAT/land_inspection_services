<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-29 11:00:31 --> 404 Page Not Found: Admin/inside_table
ERROR - 2024-04-29 11:00:36 --> 404 Page Not Found: Admin/inside
