<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-01 05:38:23 --> 404 Page Not Found: Receive/receive_case
ERROR - 2024-04-01 08:54:42 --> 404 Page Not Found: Assets/img
