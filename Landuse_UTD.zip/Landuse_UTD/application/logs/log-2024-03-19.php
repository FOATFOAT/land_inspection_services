<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-19 11:05:47 --> Severity: Warning --> Undefined variable $data_copy_land C:\xampp\htdocs\Landuse_UTD\application\models\Member_model.php 1122
ERROR - 2024-03-19 11:05:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\Landuse_UTD\application\models\Member_model.php 1122
ERROR - 2024-03-19 11:05:47 --> Severity: Warning --> Undefined variable $data_copy_land C:\xampp\htdocs\Landuse_UTD\application\models\Member_model.php 1135
ERROR - 2024-03-19 11:07:43 --> Severity: Warning --> Undefined variable $data_copy_land C:\xampp\htdocs\Landuse_UTD\application\models\Member_model.php 1135
