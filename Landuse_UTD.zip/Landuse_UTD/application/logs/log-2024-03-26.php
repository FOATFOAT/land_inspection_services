<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 04:28:43 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-26 15:00:19 --> Your server does not support the GD function required to process this type of image.
