<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-21 06:35:41 --> 404 Page Not Found: Images/5129161a4cd124e49cdd1c0cdf994a7a.jpg
ERROR - 2024-05-21 10:47:30 --> 404 Page Not Found: Admin/ui-card.html
ERROR - 2024-05-21 10:50:42 --> 404 Page Not Found: Images/8878773_20231222.jpg
ERROR - 2024-05-21 10:50:42 --> 404 Page Not Found: Images/5383385_20231222.png
