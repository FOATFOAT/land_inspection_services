<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-14 06:16:31 --> 404 Page Not Found: Admin/ui-card.html
ERROR - 2024-05-14 08:42:46 --> 404 Page Not Found: Images/4714288_20231220.png
ERROR - 2024-05-14 08:42:46 --> 404 Page Not Found: Images/3004577_20231220.jpg
ERROR - 2024-05-14 08:42:46 --> 404 Page Not Found: Images/4909430_20231220.png
ERROR - 2024-05-14 09:53:43 --> 404 Page Not Found: Images/18106bc6f3_20240502.jpg
ERROR - 2024-05-14 09:53:43 --> 404 Page Not Found: Images/c548662eba_20240502.jpg
ERROR - 2024-05-14 09:53:43 --> 404 Page Not Found: Images/9184902_20240502.png
ERROR - 2024-05-14 09:53:43 --> 404 Page Not Found: Images/7184542_20240502.jpg
ERROR - 2024-05-14 09:53:46 --> 404 Page Not Found: Images/004846daf2_20240502.jpg
ERROR - 2024-05-14 09:53:46 --> 404 Page Not Found: Images/c53d235b29_20240502.png
ERROR - 2024-05-14 09:53:46 --> 404 Page Not Found: Images/9474075_20240502.png
ERROR - 2024-05-14 09:53:46 --> 404 Page Not Found: Images/20445f353a_20240502.png
ERROR - 2024-05-14 09:53:46 --> 404 Page Not Found: Images/f750517f4f_20240502.jpg
ERROR - 2024-05-14 09:53:46 --> 404 Page Not Found: Images/1311299_20240502.jpg
ERROR - 2024-05-14 09:53:46 --> 404 Page Not Found: Images/3485132_20240502.jpg
ERROR - 2024-05-14 09:53:52 --> 404 Page Not Found: Images/8047953_20240326.jpg
ERROR - 2024-05-14 09:53:52 --> 404 Page Not Found: Images/3906423_20240326.jpg
ERROR - 2024-05-14 09:53:52 --> 404 Page Not Found: Images/e4d2678ba5_20240326.jpg
ERROR - 2024-05-14 09:53:52 --> 404 Page Not Found: Images/00c9061607_20240326.jpg
ERROR - 2024-05-14 09:53:52 --> 404 Page Not Found: Images/1944956_20240326.jpg
ERROR - 2024-05-14 09:53:55 --> 404 Page Not Found: Images/9709956_20240326.jpg
ERROR - 2024-05-14 09:53:55 --> 404 Page Not Found: Images/1881fe1ae7_20240326.jpg
ERROR - 2024-05-14 09:53:55 --> 404 Page Not Found: Images/9db28c1617_20240326.jpg
ERROR - 2024-05-14 09:53:55 --> 404 Page Not Found: Images/2f73465399_20240326.png
ERROR - 2024-05-14 09:53:55 --> 404 Page Not Found: Images/2352972_20240326.png
ERROR - 2024-05-14 09:53:55 --> 404 Page Not Found: Images/d6a55dba33_20240326.jpg
ERROR - 2024-05-14 09:53:55 --> 404 Page Not Found: Images/2147440_20240326.png
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:09 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:15 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-14 10:25:18 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = 'PER0000041'
ERROR - 2024-05-14 11:23:10 --> Severity: Warning --> Undefined variable $inside_receive_tb_ps C:\xampp\htdocs\Landuse_UTD\application\views\test.php 129
ERROR - 2024-05-14 11:23:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\Landuse_UTD\application\views\test.php 129
