<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:10 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-03-25 10:14:12 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = 'PER0000034'
ERROR - 2024-03-25 10:14:17 --> 404 Page Not Found: Images/1843119_20240318.png
ERROR - 2024-03-25 10:14:17 --> 404 Page Not Found: Images/1378798_20240318.jpg
ERROR - 2024-03-25 10:14:17 --> 404 Page Not Found: Images/2161471_20240318.png
