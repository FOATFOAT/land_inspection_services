<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-17 06:11:01 --> 404 Page Not Found: Assets_inside/thai_json
ERROR - 2024-05-17 09:16:58 --> 404 Page Not Found: Assets_inside/Tables_function
ERROR - 2024-05-17 09:17:49 --> 404 Page Not Found: Assets_inside/Tables_function
