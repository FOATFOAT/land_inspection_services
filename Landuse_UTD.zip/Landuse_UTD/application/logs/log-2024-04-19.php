<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-04-19 06:12:55 --> Severity: Warning --> Undefined variable $firstname C:\xampp\htdocs\Landuse_UTD\application\controllers\receive.php 32
ERROR - 2024-04-19 06:12:55 --> Severity: Warning --> Undefined variable $lastname C:\xampp\htdocs\Landuse_UTD\application\controllers\receive.php 33
ERROR - 2024-04-19 06:12:55 --> Severity: Warning --> Undefined variable $phone_user C:\xampp\htdocs\Landuse_UTD\application\controllers\receive.php 34
ERROR - 2024-04-19 06:12:55 --> Severity: Warning --> Undefined variable $google_maps C:\xampp\htdocs\Landuse_UTD\application\controllers\receive.php 35
ERROR - 2024-04-19 06:12:55 --> Severity: Warning --> Undefined variable $inputTextarea C:\xampp\htdocs\Landuse_UTD\application\controllers\receive.php 36
ERROR - 2024-04-19 06:12:55 --> Severity: Warning --> Undefined variable $checkedValues C:\xampp\htdocs\Landuse_UTD\application\controllers\receive.php 37
ERROR - 2024-04-19 06:14:05 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting ")" C:\xampp\htdocs\Landuse_UTD\application\controllers\receive.php 32
ERROR - 2024-04-19 06:14:35 --> Severity: Warning --> Undefined variable $firstname C:\xampp\htdocs\Landuse_UTD\application\controllers\receive.php 32
ERROR - 2024-04-19 06:14:35 --> Severity: Warning --> Undefined variable $lastname C:\xampp\htdocs\Landuse_UTD\application\controllers\receive.php 33
ERROR - 2024-04-19 06:14:35 --> Severity: Warning --> Undefined variable $phone_user C:\xampp\htdocs\Landuse_UTD\application\controllers\receive.php 34
ERROR - 2024-04-19 06:14:35 --> Severity: Warning --> Undefined variable $google_maps C:\xampp\htdocs\Landuse_UTD\application\controllers\receive.php 35
ERROR - 2024-04-19 06:14:35 --> Severity: Warning --> Undefined variable $inputTextarea C:\xampp\htdocs\Landuse_UTD\application\controllers\receive.php 36
ERROR - 2024-04-19 06:14:35 --> Severity: Warning --> Undefined variable $checkedValues C:\xampp\htdocs\Landuse_UTD\application\controllers\receive.php 37
