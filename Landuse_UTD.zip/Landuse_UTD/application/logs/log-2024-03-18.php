<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-18 03:11:27 --> Severity: error --> Exception: syntax error, unexpected token "for" C:\xampp\htdocs\Landuse_UTD\application\controllers\Admin.php 330
ERROR - 2024-03-18 03:11:43 --> Severity: error --> Exception: syntax error, unexpected token "for" C:\xampp\htdocs\Landuse_UTD\application\controllers\Admin.php 330
ERROR - 2024-03-18 03:11:49 --> Severity: error --> Exception: syntax error, unexpected token "for" C:\xampp\htdocs\Landuse_UTD\application\controllers\Admin.php 330
ERROR - 2024-03-18 03:13:54 --> Severity: error --> Exception: syntax error, unexpected token "for" C:\xampp\htdocs\Landuse_UTD\application\controllers\Admin.php 330
ERROR - 2024-03-18 03:13:55 --> Severity: error --> Exception: syntax error, unexpected token "for" C:\xampp\htdocs\Landuse_UTD\application\controllers\Admin.php 330
ERROR - 2024-03-18 10:44:31 --> Your server does not support the GD function required to process this type of image.
