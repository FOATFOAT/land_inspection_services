<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-15 16:36:52 --> The path to the image is not correct.
ERROR - 2024-03-15 16:36:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-03-15 16:36:52 --> The path to the image is not correct.
ERROR - 2024-03-15 16:36:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-03-15 16:36:52 --> The path to the image is not correct.
ERROR - 2024-03-15 16:36:52 --> Your server does not support the GD function required to process this type of image.
ERROR - 2024-03-15 16:36:52 --> The path to the image is not correct.
ERROR - 2024-03-15 16:36:52 --> Your server does not support the GD function required to process this type of image.
