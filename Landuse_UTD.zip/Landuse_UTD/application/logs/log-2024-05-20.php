<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-20 05:41:44 --> 404 Page Not Found: Assets_inside/Tables_function
ERROR - 2024-05-20 05:41:56 --> 404 Page Not Found: Assets_inside/Tables_function
ERROR - 2024-05-20 08:19:08 --> 404 Page Not Found: Admin/icon-tabler.html
ERROR - 2024-05-20 12:12:26 --> 404 Page Not Found: Admin/icon-tabler.html
