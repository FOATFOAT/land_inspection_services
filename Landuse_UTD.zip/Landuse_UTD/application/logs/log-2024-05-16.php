<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-16 04:58:29 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = 'PER0000041'
ERROR - 2024-05-16 05:00:03 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = ''
ERROR - 2024-05-16 05:04:28 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = 'PER0000010'
ERROR - 2024-05-16 09:08:23 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = 'PER0000010'
ERROR - 2024-05-16 09:48:34 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = ''
ERROR - 2024-05-16 11:25:37 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = 'PER0000010'
ERROR - 2024-05-16 11:25:40 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = ''
ERROR - 2024-05-16 11:25:43 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = ''
ERROR - 2024-05-16 11:26:09 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = 'PER0000020'
ERROR - 2024-05-16 11:26:16 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = 'PER0000020'
ERROR - 2024-05-16 11:31:08 --> 404 Page Not Found: Images/4714288_20231220.png
ERROR - 2024-05-16 11:31:08 --> 404 Page Not Found: Images/3004577_20231220.jpg
ERROR - 2024-05-16 11:31:08 --> 404 Page Not Found: Images/4909430_20231220.png
ERROR - 2024-05-16 11:31:12 --> 404 Page Not Found: Images/4714288_20231220.png
ERROR - 2024-05-16 11:31:12 --> 404 Page Not Found: Images/3004577_20231220.jpg
ERROR - 2024-05-16 11:31:12 --> 404 Page Not Found: Images/4909430_20231220.png
ERROR - 2024-05-16 11:31:25 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = 'PER0000040'
ERROR - 2024-05-16 11:31:28 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = 'PER0000036'
