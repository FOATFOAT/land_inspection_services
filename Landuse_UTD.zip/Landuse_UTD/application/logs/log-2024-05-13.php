<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-13 04:47:47 --> 404 Page Not Found: Images/c53d235b29_20240502.png
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-13 04:47:47 --> 404 Page Not Found: Images/9474075_20240502.png
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-13 04:47:47 --> 404 Page Not Found: Images/20445f353a_20240502.png
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-13 04:47:47 --> 404 Page Not Found: Images/004846daf2_20240502.jpg
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-13 04:47:47 --> 404 Page Not Found: Images/f750517f4f_20240502.jpg
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-13 04:47:47 --> 404 Page Not Found: Images/1311299_20240502.jpg
ERROR - 2024-05-13 04:47:47 --> 404 Page Not Found: Images/3485132_20240502.jpg
ERROR - 2024-05-13 05:39:33 --> 404 Page Not Found: Images/c53d235b29_20240502.png
ERROR - 2024-05-13 05:39:33 --> 404 Page Not Found: Images/004846daf2_20240502.jpg
ERROR - 2024-05-13 05:39:33 --> 404 Page Not Found: Images/9474075_20240502.png
ERROR - 2024-05-13 05:39:33 --> 404 Page Not Found: Images/20445f353a_20240502.png
ERROR - 2024-05-13 05:39:33 --> 404 Page Not Found: Images/f750517f4f_20240502.jpg
ERROR - 2024-05-13 05:39:33 --> 404 Page Not Found: Images/1311299_20240502.jpg
ERROR - 2024-05-13 05:39:33 --> 404 Page Not Found: Images/3485132_20240502.jpg
ERROR - 2024-05-13 05:52:28 --> 404 Page Not Found: Images/004846daf2_20240502.jpg
ERROR - 2024-05-13 05:52:28 --> 404 Page Not Found: Images/f750517f4f_20240502.jpg
ERROR - 2024-05-13 05:52:28 --> 404 Page Not Found: Images/c53d235b29_20240502.png
ERROR - 2024-05-13 05:52:28 --> 404 Page Not Found: Images/20445f353a_20240502.png
ERROR - 2024-05-13 05:52:28 --> 404 Page Not Found: Images/9474075_20240502.png
ERROR - 2024-05-13 05:52:28 --> 404 Page Not Found: Images/1311299_20240502.jpg
ERROR - 2024-05-13 05:52:28 --> 404 Page Not Found: Images/3485132_20240502.jpg
ERROR - 2024-05-13 05:52:31 --> 404 Page Not Found: Images/7184542_20240502.jpg
ERROR - 2024-05-13 05:52:31 --> 404 Page Not Found: Images/c548662eba_20240502.jpg
ERROR - 2024-05-13 05:52:31 --> 404 Page Not Found: Images/9184902_20240502.png
ERROR - 2024-05-13 05:52:31 --> 404 Page Not Found: Images/18106bc6f3_20240502.jpg
ERROR - 2024-05-13 06:02:53 --> 404 Page Not Found: Images/4714288_20231220.png
ERROR - 2024-05-13 06:02:53 --> 404 Page Not Found: Images/3004577_20231220.jpg
ERROR - 2024-05-13 06:02:53 --> 404 Page Not Found: Images/4909430_20231220.png
ERROR - 2024-05-13 06:03:11 --> 404 Page Not Found: Images/004846daf2_20240502.jpg
ERROR - 2024-05-13 06:03:11 --> 404 Page Not Found: Images/f750517f4f_20240502.jpg
ERROR - 2024-05-13 06:03:11 --> 404 Page Not Found: Images/c53d235b29_20240502.png
ERROR - 2024-05-13 06:03:11 --> 404 Page Not Found: Images/20445f353a_20240502.png
ERROR - 2024-05-13 06:03:11 --> 404 Page Not Found: Images/9474075_20240502.png
ERROR - 2024-05-13 06:03:11 --> 404 Page Not Found: Images/1311299_20240502.jpg
ERROR - 2024-05-13 06:03:11 --> 404 Page Not Found: Images/3485132_20240502.jpg
ERROR - 2024-05-13 06:12:33 --> 404 Page Not Found: Images/4909430_20231220.png
ERROR - 2024-05-13 06:12:33 --> 404 Page Not Found: Images/4714288_20231220.png
ERROR - 2024-05-13 06:12:33 --> 404 Page Not Found: Images/3004577_20231220.jpg
ERROR - 2024-05-13 06:31:38 --> 404 Page Not Found: Images/f750517f4f_20240502.jpg
ERROR - 2024-05-13 06:31:38 --> 404 Page Not Found: Images/004846daf2_20240502.jpg
ERROR - 2024-05-13 06:31:38 --> 404 Page Not Found: Images/1311299_20240502.jpg
ERROR - 2024-05-13 06:31:38 --> 404 Page Not Found: Images/9474075_20240502.png
ERROR - 2024-05-13 06:31:38 --> 404 Page Not Found: Images/20445f353a_20240502.png
ERROR - 2024-05-13 06:31:38 --> 404 Page Not Found: Images/c53d235b29_20240502.png
ERROR - 2024-05-13 06:31:38 --> 404 Page Not Found: Images/3485132_20240502.jpg
ERROR - 2024-05-13 09:12:52 --> 404 Page Not Found: Images/3004577_20231220.jpg
ERROR - 2024-05-13 09:12:52 --> 404 Page Not Found: Images/4714288_20231220.png
ERROR - 2024-05-13 09:12:52 --> 404 Page Not Found: Images/4909430_20231220.png
ERROR - 2024-05-13 09:23:08 --> 404 Page Not Found: Images/4714288_20231220.png
ERROR - 2024-05-13 09:23:08 --> 404 Page Not Found: Images/4909430_20231220.png
ERROR - 2024-05-13 09:23:08 --> 404 Page Not Found: Images/3004577_20231220.jpg
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:51 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 10:05:54 --> Query error: Unknown column 'bl_submit_person.company_id' in 'where clause' - Invalid query: SELECT *, `bl_sum_copy_land_deed`.`person_id`, `bl_sum_copy_land_deed`.`copy_land_deed`
FROM `bl_submit_person`
LEFT JOIN `bl_sum_copy_land_deed` ON `bl_sum_copy_land_deed`.`company_id` = `bl_submit_person`.`person_id`
WHERE `bl_submit_person`.`company_id` = 'PER0000041'
ERROR - 2024-05-13 10:26:08 --> Severity: error --> Exception: Invalid numeric literal C:\xampp\htdocs\Landuse_UTD\application\models\Member_model.php 145
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:29:26 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 11:30:30 --> Severity: Warning --> Undefined property: stdClass::$company_name C:\xampp\htdocs\Landuse_UTD\application\views\inside_receive_tb_ps_view.php 111
ERROR - 2024-05-13 12:27:53 --> 404 Page Not Found: Images/5129161a4cd124e49cdd1c0cdf994a7a.jpg
