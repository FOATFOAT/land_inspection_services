<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-03-13 15:01:36 --> Severity: Warning --> Undefined variable $date_name C:\xampp\htdocs\Landuse_UTD\application\models\Member_model.php 637
ERROR - 2024-03-13 15:01:36 --> Severity: Warning --> Undefined variable $date_name C:\xampp\htdocs\Landuse_UTD\application\models\Member_model.php 637
ERROR - 2024-03-13 15:01:36 --> Severity: Warning --> Undefined variable $date_name C:\xampp\htdocs\Landuse_UTD\application\models\Member_model.php 637
ERROR - 2024-03-13 15:01:36 --> Severity: Warning --> Undefined variable $date_name C:\xampp\htdocs\Landuse_UTD\application\models\Member_model.php 637
ERROR - 2024-03-13 16:16:40 --> Severity: error --> Exception: Call to undefined method Member_model::generateUniqueFileName() C:\xampp\htdocs\Landuse_UTD\application\models\Member_model.php 376
ERROR - 2024-03-13 16:28:13 --> Severity: error --> Exception: Call to undefined method Member_model::generateUniqueFileName() C:\xampp\htdocs\Landuse_UTD\application\models\Member_model.php 376
